## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
library(select)
library(dplyr)

## -----------------------------------------------------------------------------
# Check the data strucutre
## Load the data provided with the package
data(luad_data, package = "select")
str(luad_data)

## -----------------------------------------------------------------------------
alpi <- select::select(
  M = luad_data$gam,
  sample.class = luad_data$samples,
  alteration.class = luad_data$alt,
  folder = './',
  r.seed = 110,
  n.cores = 1,
  vetos = NULL,
  n.permut = 100,
  min.feature.support=5,
  min.feature.freq=0.001,
  remove.0.samples=TRUE,
  remove.unknown.class.samples=TRUE,
  rho = 0.1,
  lambda = 15,
  save.intermediate.files = FALSE,
  randomization.switch.threshold = 30,
  max.memory.size=100,
  calculate_APC_threshold = TRUE,
  calculate_FDR = TRUE,
  FDR.cutoff=0.1,
  verbose = TRUE
  )

## -------------------------------------------------------------------------------------------------
options(width=100)
# Look into dataframe
(alpi %>% filter(wMI_p.value_FDR) %>% arrange(desc(select_score))) %>% head(2) 
# Total significant Hits
alpi  %>% filter(wMI_p.value_FDR) %>% count(wMI_p.value_FDR,direction)

## -------------------------------------------------------------------------------------------------
# Print the sessionInfo
sessionInfo()

